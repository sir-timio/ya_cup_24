import gc
import json
import os
import random
from copy import deepcopy
import pytorch_lightning as pl
from pytorch_lightning import Trainer
from pytorch_lightning.callbacks import ModelCheckpoint, EarlyStopping
from pytorch_lightning.loggers import CSVLogger
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

if not os.path.exists("submissions"):
    os.mkdir("submissions")

from src.dataset.utils import (
    read_testcase_ids,
    read_sample,
    create_meta_mapping,
    read_metadata,
)
from src.dataset.test_ds import TestDataset
from src.dataset.train_ds import TrajectoryDataset
from src.metric import calculate_metric_on_batch
from src.modeling import (
    LstmEncoderDecoder,
    LstmEncoderDecoderWithAttention,
    LstmEncoderDecoderWithLuongAttention,
    LstmEncoderDecoderWithDualAttention,
)

from src.lightning import TrajectoryLightningModule


def seed_everything(seed: int):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

ROOT_DATA_FOLDER = "./dataset"

TRAIN_DATASET_PATH = os.path.join(ROOT_DATA_FOLDER, "YaCupTrain")
TEST_DATASET_PATH = os.path.join(ROOT_DATA_FOLDER, "YaCupTest")
META_PATH = os.path.join(ROOT_DATA_FOLDER, "mapping.json")


################ CONFIG ##########################
FOLD = 1
NUM_LAYERS = 3
HIDDEN_SIZE = 196
LSTM_CLS = LstmEncoderDecoderWithDualAttention
ATTN = "dual_attn"
SEED = 52 + ((FOLD * 100) + 100 * NUM_LAYERS) % 71 + HIDDEN_SIZE

VAL_RATIO = 0.15
SCHEDULER_PATIENCE = 20
LR = 1e-3
WD = 1e-4
EPOCHS = 3_000
BATCH_SIZE = 512
################ EOC ##########################

embedding_dim = 16
localization_input_size = 6  # For example, x, y, z, roll, pitch, yaw
control_input_size = 2  # acceleration_level, steering

DEVICE = "cuda"


EXP_NAME = f"lstm_{ATTN}_{NUM_LAYERS}_{HIDDEN_SIZE}"


if __name__ == "__main__":
    seed_everything(SEED)

    train_ids = read_testcase_ids(TRAIN_DATASET_PATH)
    print(len(train_ids))

    random.shuffle(train_ids)
    val_size = int(len(train_ids) * VAL_RATIO)
    val_identifiers = set(train_ids[:val_size])
    train_identifiers = set(train_ids[val_size:])

    if not os.path.exists(META_PATH):
        metas = []
        for testcase_id in tqdm(train_ids, desc="create meta mapping"):
            meta = read_metadata(
                os.path.join(TRAIN_DATASET_PATH, str(testcase_id), "metadata.json")
            )
            metas.append(meta)
        mapping = create_meta_mapping(metas)

        with open(META_PATH, "w") as f:
            json.dump(mapping, f)

    mapping = json.load(open(META_PATH, "r"))
    for k, v in mapping.items():
        mapping[k]["map"] = {int(k): int(v) for k, v in v["map"].items()}
        mapping[k]["unk"] = int(v["unk"])
        assert v["unk"] in mapping[k]["map"]

    vehicle_feature_sizes = {k: len(v["map"]) for k, v in mapping.items()}

    model = LSTM_CLS(
        vehicle_feature_sizes=vehicle_feature_sizes,
        embedding_dim=embedding_dim,
        localization_input_size=localization_input_size,
        control_input_size=control_input_size,
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS,
    ).to(DEVICE)

    train_dataset = TrajectoryDataset(
        TRAIN_DATASET_PATH,
        mapping,
        testcase_ids=list(train_identifiers)[:],
        training=True,
    )
    val_dataset = TrajectoryDataset(
        TRAIN_DATASET_PATH,
        mapping,
        testcase_ids=list(val_identifiers)[:],
        training=False,
    )
    test_dataset = TestDataset(TEST_DATASET_PATH, mapping)

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=0,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=0,
    )

    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, collate_fn=None)


    logger = CSVLogger("lightning_logs", name=EXP_NAME, version=f"fold_{FOLD}")

    checkpoint_callback = ModelCheckpoint(
        monitor="val_loss", filename="best_model", save_top_k=1, mode="min"
    )

    callbacks = [
        checkpoint_callback,
        pl.callbacks.LearningRateMonitor(logging_interval="epoch"),
    ]
    lightning_module = TrajectoryLightningModule(
        model=model, learning_rate=LR, weight_decay=WD, scheduler_patience=SCHEDULER_PATIENCE
    )

    trainer = pl.Trainer(
        logger=logger,
        max_epochs=EPOCHS,
        check_val_every_n_epoch=1,
        callbacks=callbacks,
    )
    trainer.fit(lightning_module, train_loader, val_loader)
    
    torch.cuda.empty_cache()
    gc.collect()
    with torch.no_grad():
        torch.cuda.empty_cache()
    gc.collect()

    lightning_module = TrajectoryLightningModule.load_from_checkpoint(
        checkpoint_callback.best_model_path, model=model
    )
    lightning_module.eval()
    lightning_module.model.eval()
    lightning_module.model.to(DEVICE)
    predictions = []

    with torch.inference_mode():
        for sample in tqdm(test_loader):
            for k, v in sample.items():
                sample[k] = v.to("cuda")

            start_position = sample["start_position"].detach().cpu().numpy()[0]
            requested_stamps = sample["requested_stamps"].detach().cpu().numpy()[0]
            testcase_id = sample["testcase_id"].detach().cpu().item()

            predicted_output_localization = lightning_module(sample)

            time_steps = np.arange(5 * 1e9, 20 * 1e9, 4e7)

            predicted_output_localization = (
                predicted_output_localization.detach().cpu().numpy()[0]
            )
            predicted_output_localization[:, :3] += start_position

            # Извлечение предсказанных координат и углов
            yaw_pred = predicted_output_localization[:, -1]
            x_pred = predicted_output_localization[:, 0]
            y_pred = predicted_output_localization[:, 1]

            # Интерполяция координат x и y
            x_interp = np.interp(
                requested_stamps, time_steps, x_pred, left=x_pred[0], right=x_pred[-1]
            )
            y_interp = np.interp(
                requested_stamps, time_steps, y_pred, left=y_pred[0], right=y_pred[-1]
            )

            yaw_interp = np.interp(
                requested_stamps,
                time_steps,
                yaw_pred,
                left=yaw_pred[0],
                right=yaw_pred[-1],
            )

            assert len(requested_stamps) == len(x_interp)
            assert len(requested_stamps) == len(y_interp)
            assert len(requested_stamps) == len(yaw_interp)

            for stamp_ns, x, y, yaw in zip(
                requested_stamps, x_interp, y_interp, yaw_interp
            ):
                predictions.append(
                    {
                        "testcase_id": int(testcase_id),
                        "stamp_ns": int(stamp_ns),
                        "x": x,
                        "y": y,
                        "yaw": yaw,
                    }
                )
    predictions = pd.DataFrame(predictions)
    predictions["testcase_id"] = predictions["testcase_id"].apply(int)
    predictions = predictions.sort_values(by=["testcase_id", "stamp_ns"])
    predictions.to_csv(
        f'submissions/{EXP_NAME}_fold_{FOLD}".csv.gz',
        index=False,
        compression="gzip",
    )
